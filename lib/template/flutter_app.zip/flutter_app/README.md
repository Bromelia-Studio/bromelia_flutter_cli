# flutter_app

A new Flutter project generated with bromelia_cli.
